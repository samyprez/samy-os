import {
  CalendarClock,
  CircleDollarSign,
  ListChecks,
  MessageSquareText,
  Plus,
  Sparkles,
  Users
} from "lucide-react";
import { Sidebar } from "../components/Sidebar";
import { StatCard } from "../components/StatCard";

const tasks = [
  ["Salami Sibao", "Terminar actualización web", "Alta"],
  ["MiKiosko.ca", "Crear contenido con productos reales", "Alta"],
  ["TorontoDominicano", "Planificar calendario comunitario", "Media"]
];

export default function Home() {
  return (
    <main className="shell">
      <Sidebar />

      <section className="workspace">
        <header className="topbar">
          <div>
            <span className="eyebrow">Martes, 4 de agosto</span>
            <h1>Buenas tardes, Samy.</h1>
            <p>Esto es lo más importante para mover hoy.</p>
          </div>
          <button className="primaryButton"><Plus size={18} /> Nueva acción</button>
        </header>

        <section className="statsGrid">
          <StatCard label="Clientes activos" value="2" note="2 de alta prioridad" icon={Users} />
          <StatCard label="Pendientes" value="3" note="2 requieren atención" icon={ListChecks} />
          <StatCard label="Agenda" value="0" note="Sin reuniones hoy" icon={CalendarClock} />
          <StatCard label="Ingresos" value="$0" note="Módulo próximo" icon={CircleDollarSign} />
        </section>

        <section className="assistantCard">
          <div className="assistantIcon"><Sparkles size={22} /></div>
          <div>
            <span className="eyebrow">Asistente ejecutivo</span>
            <h2>Pregúntale a Samy OS</h2>
            <p>Consulta clientes, tareas, reuniones y próximos pasos desde un solo lugar.</p>
          </div>
          <button className="secondaryButton"><MessageSquareText size={18} /> Hablar con Samy OS</button>
        </section>

        <section className="contentGrid">
          <article className="panel">
            <div className="panelHeader">
              <div>
                <span className="eyebrow">Prioridades</span>
                <h2>Próximas tareas</h2>
              </div>
              <button className="textButton">Ver todas</button>
            </div>

            <div className="taskList">
              {tasks.map(([client, task, priority]) => (
                <div className="taskRow" key={task}>
                  <div className="check" />
                  <div className="taskText">
                    <strong>{task}</strong>
                    <span>{client}</span>
                  </div>
                  <span className={priority === "Alta" ? "badge high" : "badge"}>{priority}</span>
                </div>
              ))}
            </div>
          </article>

          <article className="panel focusPanel">
            <span className="eyebrow">Enfoque recomendado</span>
            <h2>Salami Sibao</h2>
            <p>Termina la actualización web y luego confirma el seguimiento con la representante de Toronto.</p>
            <button className="primaryButton wide">Abrir cliente</button>
          </article>
        </section>
      </section>
    </main>
  );
}
