import type { LucideIcon } from "lucide-react";

type Props = {
  label: string;
  value: string;
  note: string;
  icon: LucideIcon;
};

export function StatCard({ label, value, note, icon: Icon }: Props) {
  return (
    <article className="statCard">
      <div className="statIcon"><Icon size={19} /></div>
      <span>{label}</span>
      <strong>{value}</strong>
      <small>{note}</small>
    </article>
  );
}
