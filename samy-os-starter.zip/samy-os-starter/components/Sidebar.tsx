import {
  LayoutDashboard,
  Users,
  ListChecks,
  CalendarDays,
  BriefcaseBusiness,
  NotebookPen,
  HeartPulse,
  Settings
} from "lucide-react";

const items = [
  ["Dashboard", LayoutDashboard],
  ["Clientes", Users],
  ["Pendientes", ListChecks],
  ["Calendario", CalendarDays],
  ["Marcas", BriefcaseBusiness],
  ["Notas", NotebookPen],
  ["Salud", HeartPulse],
  ["Configuración", Settings]
] as const;

export function Sidebar() {
  return (
    <aside className="sidebar">
      <div className="brand">
        <div className="brandMark">S</div>
        <div>
          <strong>Samy OS</strong>
          <span>Centro de operaciones</span>
        </div>
      </div>

      <nav>
        {items.map(([label, Icon], index) => (
          <button className={index === 0 ? "navItem active" : "navItem"} key={label}>
            <Icon size={18} strokeWidth={1.8} />
            <span>{label}</span>
          </button>
        ))}
      </nav>
    </aside>
  );
}
