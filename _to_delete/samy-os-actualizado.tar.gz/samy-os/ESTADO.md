# Estado de Samy OS

> **Para qué sirve este archivo.** Es el resumen de contexto del proyecto. Súbelo
> al Proyecto de Claude (o pásalo al inicio de un chat nuevo) para que el
> asistente sepa dónde vamos sin tener que reconstruirlo desde los commits.
> Cuando cambie algo importante, actualízalo — es la memoria del proyecto.

**Última actualización:** 20 de agosto de 2026
**Repo:** https://github.com/samyprez/samy-os
**Producción:** https://samy-os-seven.vercel.app (Vercel, deploy automático desde `main`)

---

## Qué es Samy OS

El backend operativo y el dashboard de **Walie**, el asistente de Samuel.
La superficie principal de conversación es **ChatGPT** (vía GPT Action); el
dashboard web es para revisión visual y control manual.

```
ChatGPT / voz  →  API segura de Samy OS  →  Supabase + Hub + Google  →  dashboard
```

Todo pasa por un solo cerebro: `lib/server/gateway-operations.ts`
(`runGatewayOperation`). Tres puertas distintas entran ahí:

| Puerta | Ruta | Autenticación |
|---|---|---|
| ChatGPT | `POST /api/chatgpt` | Bearer `ASSISTANT_API_KEY` |
| Dashboard y voz en el navegador | `POST /api/dashboard` | Token de sesión Supabase del usuario |
| Enviar correo (aparte, a propósito) | `POST /api/chatgpt/send-email` y `/api/dashboard/send-email` | igual que arriba |

Enviar correo vive en su propia ruta porque ChatGPT marca la confirmación
**por operación**, no por campo: el gateway principal es
`x-openai-isConsequential: false` (para que la voz funcione sin preguntar cada
vez) y enviar correo es `true` (siempre confirma).

---

## Dónde vive cada dato (esto cambió el 10–11 de agosto)

| Dato | Vive en | Módulo |
|---|---|---|
| **Tareas** (`list_tasks`, `create_task`, `complete_task`) | **Amazing Business Hub** — son *proyectos* del Hub | `lib/server/hub.ts` |
| **Proyectos, clientes, facturas** | **Amazing Business Hub** | `lib/server/hub.ts` |
| **Notas** (`list_notes`, `create_note`) | **Hub**, en el tablero de recordatorios | `lib/server/hub.ts` |
| **Eventos** (`list_events`, `create_event`, `delete_event`) | **Google Calendar real** (calendario `primary`) | `lib/server/calendar.ts` |
| **Correo** (`search_email`, `read_email`, enviar) | **Gmail API** | `lib/server/gmail.ts` |
| **Salud** (`list_health`, `create_health`) | Supabase de Samy OS, tabla `health_entries` | gateway |
| **Marcas** (`list_brands`, `create_brand`) | Supabase de Samy OS | gateway |
| **WhatsApp** (empezado, no terminado) | WhatsApp Business Cloud API | `lib/server/whatsapp.ts` |

**Las tablas propias de Samy OS para tareas, clientes, notas y eventos quedaron
retiradas.** Los nombres de operación (`create_task`, etc.) se conservaron
porque son el vocabulario que ChatGPT ya conocía, pero por dentro son alias
sobre el Hub.

Nota importante sobre el Hub: su esquema se leyó de la base de datos en vivo,
**no** de las migraciones del repo, porque esas ya no coinciden.
`projects.status` es `pending|in_progress|monthly|urgent|completed`, y los
clientes usan `company_name`, no `name`.

---

## Integraciones

### Google (Gmail + Calendar) — una sola cuenta OAuth
Google emite **un** refresh token por (cliente, conjunto de scopes), así que
Calendar no necesitó una segunda app: solo se amplió el scope que Samuel
autoriza. Los dos módulos comparten `getAccessToken()` de `gmail.ts`.

Scopes: `gmail.readonly`, `gmail.send`, `calendar`.

**Trampa conocida:** si la app de Google Cloud sigue en modo **Testing**, el
refresh token **caduca a los 7 días**. Si `/api/health` reporta
`gmail.works: false` con `invalid_grant`, hay que volver a generar el token
abriendo:
`https://samy-os-seven.vercel.app/api/google/auth?token=<ASSISTANT_API_KEY>`
y copiando el valor que imprime el callback (Google no lo vuelve a mostrar).
Publicar la app quita esa caducidad.

Si Calendar da error de *insufficient scope*, es que el refresh token es
anterior al consentimiento de Calendar → volver a generarlo.

### ChatGPT (GPT Action)
El OpenAPI se genera de una sola fuente: `lib/server/openapi-schema.ts`, servido
en `/openapi.json` y `/api/chatgpt/openapi`.

**Nunca crear `public/openapi.json`** — un archivo ahí tapa la ruta y las dos
copias se separan; ese fue exactamente el bug que apuntó ChatGPT al endpoint
equivocado.

**Después de agregar una operación hay que re-importar el esquema en el editor
del GPT** (Configurar → Acciones → engranaje → Importar desde URL). Si no,
ChatGPT sigue con el contrato viejo y dice, con razón, que no tiene esa acción.

### WhatsApp Business (a medias)
Coexistence activado: Samuel sigue usando la app de WhatsApp Business en el
teléfono y la API ve las mismas conversaciones. Dos límites de Meta mandan el
diseño: la ventana de 24 h (fuera de ella solo plantillas aprobadas) y los
webhooks que se reintentan, así que los handlers son idempotentes y responden
200 rápido. Webhook en `app/api/whatsapp/webhook/route.ts`.

---

## Variables de entorno en Vercel

```text
# Samy OS (Supabase propio)
NEXT_PUBLIC_SUPABASE_URL
NEXT_PUBLIC_SUPABASE_ANON_KEY
SUPABASE_SERVICE_ROLE_KEY
SAMY_OS_OWNER_USER_ID        # preferido, o SAMY_OS_OWNER_EMAIL

# Amazing Business Hub (Supabase aparte)
HUB_SUPABASE_URL
HUB_SUPABASE_SERVICE_ROLE_KEY

# Asistente
OPENAI_API_KEY
OPENAI_MODEL
ASSISTANT_API_KEY            # el bearer del gateway (legacy: SAMY_OS_API_TOKEN)

# Google (Gmail + Calendar)
GOOGLE_CLIENT_ID
GOOGLE_CLIENT_SECRET
GOOGLE_REFRESH_TOKEN

# WhatsApp
WHATSAPP_VERIFY_TOKEN
WHATSAPP_APP_SECRET
```

`SUPABASE_SERVICE_ROLE_KEY` y `ASSISTANT_API_KEY` **nunca** van al navegador.

**Dónde está la service-role key:** Supabase ya no usa la palabra "service role"
en ningún lado. Está en **Settings → API Keys → "Secret keys"**, como un valor
`sb_secret_...`. La "Publishable key" (`sb_publishable_...`) de la misma página
es la pública y no sirve. Copiar con el ícono, no a mano — el id del proyecto
está al lado y es fácil agarrarlo por error.

**Verificación:** `GET /api/health` distingue *configurado* de *funciona de
verdad* — ejerce la service-role key y el refresh token con llamadas reales.
`chatgptGateway` tiene que ser `true`.

---

## Pendientes conocidos

1. **El dashboard quedó desconectado del cerebro nuevo.**
   `app/components/SamyOSApp.tsx` todavía lee y escribe directo a Supabase con
   `supabase.from("tasks")`, `from("clients")`, `from("notes")`,
   `from("events")` — justo las tablas que se retiraron. La ruta
   `/api/dashboard` ya existe y usa `runGatewayOperation`, pero la UI solo la
   usa para el correo. Resultado: ChatGPT ve el Hub y el Google Calendar real,
   y el dashboard ve tablas viejas o vacías. **Este es el trabajo más obvio que
   sigue.**

2. **El README está desactualizado.** No documenta el Hub, Google Calendar,
   WhatsApp ni las operaciones de salud. Este archivo (`ESTADO.md`) lo cubre
   mientras tanto.

3. **WhatsApp está a medias** — el webhook y el módulo existen, falta cerrar el
   flujo.

4. **Las migraciones de `supabase/` ya no reflejan la realidad**, ni las de Samy
   OS ni las del Hub. No confiar en ellas; leer el esquema en vivo.

---

## Copias de seguridad

- **Online:** GitHub `samyprez/samy-os`, rama `main`. Es la fuente de verdad.
- **PC:** `C:\Users\samyp\samy-os`
- Vercel despliega solo desde `main`, así que lo que está en GitHub es lo que
  está en producción.
